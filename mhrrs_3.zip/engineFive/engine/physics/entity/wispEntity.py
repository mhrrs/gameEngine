

class Wisp(object):
    def __init__(self, name = "wisp"):
        self.position = []
        self.

        self.octaves1 = None

    def perlinNoise1(self,x):
        if self.fspn1 == None:
            import engine.fx.action as fa
            self.fspn1 = fa.FractalSummedPerlinNoise(self.octaves1, self.fjump1, self.rougness1, self.freq1, self.translate1)
            return self.fspn1.noise(x)