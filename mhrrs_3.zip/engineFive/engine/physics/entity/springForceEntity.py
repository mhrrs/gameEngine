class SpringyForce(object):
    def __init__(self, name = "Springy_Force_Entity"):
        self.spring_constant = .0025
        self.actions = []
        self.name = name
        self.verbose = False
        self.active = True
        return

    def insert_action(self, action):
        action.entity_state = self
        self.actions.append(action)
        return