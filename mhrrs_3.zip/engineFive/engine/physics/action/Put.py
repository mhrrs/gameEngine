

class PutPositionAction(object):
    def __init__(self):
        self.types = ["position"]
        self.name = "put_position_action"
        self.children = []
        self.entity_state = None
        self.verbose = False

    def condition_to_act(self, data):
        if self.entity_state == None:
            return False
        if self.entity_state.active == None:
            return False
        if len(data) != 2:
            return False
        return True

    def act(self, data):
        print("PP:", self.entity_state)
        if self.condition_to_act(data):
            x = int(data[0]- self.entity_state.position[0] * 0.5)
            y = int(data[1]- self.entity_state.position[1] * 0.5)
            self.entity_state.position = (x,y)
            for c in self.children:
                c.act(data)
            if self.verbose == True:
                print(self.name + " for " + self.entity_state.name)
        return