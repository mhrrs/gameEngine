class LeapFrogSolveAction(object):
    def __init__(self):
        self.types = ["physics"]
        self.entity_state = None
        self.dt = 1.0
        self.name = "leap_frog_solve_action"
        self.verbose = False
        self.children = []

    def condition_to_act(self, data):
        if self.entity_state == False:
            return False
        if self.entity_state.active == False:
            return False
        # if there are fewer than 2 children, the solver is not usable
        if len(self.children) < 2:
            return False
        return True

    def act(self,data):
        if self.condition_to_act(data):
            # first two children are part of the solve
            self.children[0].dt = self.dt*0.5
            self.children[1].dt = self.dt
            self.children[0].act(data) #half step of first child
            self.children[1].act(data) #full step of second child
            self.children[0].act(data) #half step of first child
            # any other children operate here:
            for c in self.children[2:]:
                c.act(data)
            if self.verbose:
                print(self.name + " for " + self.entity_state.name)

        return