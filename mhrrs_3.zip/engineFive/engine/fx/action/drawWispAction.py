

class DrawWispAction():
    def __init__(self)