import pygame, sys
from pygame.locals import *
import random

# adding folders
sys.path.append('C://Users//Michael Harris//Desktop//Masters CS//Clemson MSCS//2D_gameEngineConstruction//cannon_fodder//engineFive//engine')

import actor as ac
import play as pl
import ui as ui
import utility as util
import sound as snd



#######################################
##
## random_color and random position
##

def random_color():
    rred = random.randrange(0,255)
    rgreen = random.randrange(0,255)
    rblue = random.randrange(0,255)
    return (rred,rgreen,rblue)


def random_pos():
    randx = random.choice(range(0,1280))
    randy = random.choice(range(0,720))
    return (randx,randy)


##
## GET_CIRCLES METHOD
##

def get_circles(nx, ny, nb):
    circles = []
    radius = 10
    for i in range(0,nb):
        circle_bounds = random_pos()
        circle_color = random_color()

        circle = ac.make_basic_circle(circle_bounds[0],circle_bounds[1],radius)
        circle.color = circle_color
        circle.verbose = True
        circle.insert_action(ac.make_draw_circle())
        circles.append(circle)

    return circles
#######################################


#######################################
##
## PHYSICS
##

def get_particles(init_data, nx, ny):
    import physics as ph
    particles = []

    parts = ph.make_particle()
    particles.append(parts)

    for d in init_data:
        position = list(d.position)
        velocity = [(2.0*random.random()-1.0), (2.0*random.random()-1.0)]
        mass = 1.0
        parts.add_particle(position, velocity, mass)
    
    # force. In this case, simple gravity
    gravity = ph.make_gravity_force()
    gravity.gravity = [0.0,0.01]
    grav_action = ph.make_gravity_action()
    gravity.insert_action(grav_action)

    psolve = ph.make_position_solve_action()
    parts.insert_action(psolve)

    vsolve = ph.make_velocity_solve_action()
    parts.insert_action(vsolve)
    vsolve.children.append(grav_action)

    esolve = ph.make_euler_solve_action()
    esolve.dt = 0.1
    parts.insert_action(esolve)
    esolve.children.append(psolve)
    esolve.children.append(vsolve)
    esolve.types.append("loop")


    # connect particle positions to circle positions
    for i in range(0, len(init_data)):
        pick = ph.make_pick_position_action(i)
        put = ph.make_put_position_action()
       
        parts.insert_action(pick)
        init_data[i].insert_action(put)
        pick.children.append(put)

        esolve.children.append(pick)


    # collisions with window frame
    window_frame_collider = ph.make_rectangle_collider([0,0], [nx,ny])
    collisions = ph.make_inside_rectangle_collision()
    window_frame_collider.insert_action(collisions)
    psolve.children.append(collisions)

    # collisions with a rectangle in the center of the frame
    box_collider = ph.make_rectangle_collider([nx/2-200,ny/2-200], [nx/2+200,ny/2+200])
    outside_collisions = ph.make_outside_rectangle_collision()
    box_collider.insert_action(outside_collisions)
    psolve.children.append(outside_collisions)

    return particles


#######################################
##
## get_boxes
##
def get_boxes(nx,ny):
    boxes = []
    rect = ac.make_basic_rectangle(nx/2-200.0,ny/2-200.0,400,400,(255,255,255))
    # rect.position = [nx/2-200.0,ny/2-200.0]
    rect.insert_action(ac.make_draw_rectangle())
    boxes.append(rect)
    return boxes



#######################################

def main():
    pygame.init()

    # display window
    viewer = pl.frameViewerEntity(title = "Cannon Fodder", name = "Cannon Fodder Window")
    viewer.insert_action(pl.make_terminate_action())
    display = pl.make_frameViewerAction()

    NX = 1280
    NY = 720

    # create 100 spheres
    circs = get_circles(NX,NY,100)
    particles = get_particles(circs, NX, NY)
    boxes = get_boxes(NX, NY)


    # inserting window into frameviewer entity
    viewer.insert_action(display)

    # adding entities to game_content
    game_content = [viewer]

    # adding circs and particles
    game_content += circs + particles + boxes

    # pass draw action to the gameLooper
    for b in circs+boxes:
        display.insert_entity(b)
        print("circ pos: ",b.position)
    
    for p in particles:
        print("particles pos: ", p.position)


    # run game loop
    game = pl.make_gameLoopAction(game_content)
    game.loop()


main()