from pygame.locals import *
import pygame

class is_inside(object):
    def __init__(self):
        self.types = ["position"]
        self.active = True
        self.verbose = False
        self.name = "is_inside_action"
        self.children = []
        self.inactive_particles = []


    # data being pumped in should be the position of particles
    def condition_to_act(self, data):
        if self.entity_state == False:
            return False
        if self.entity_state.active == False:
            return False
        if data == None:
            return False
        return True


    def act(self, data):
        if self.condition_to_act(data):
            inactive_particles = []
            for i in range(0, len(data.active_particle)):
                if self.is_inside(data.position[i]):
                    inactive_particles.append(i)
            
                    for c in self.children:
                        c.act(inactive_particles)

            if self.verbose:
                print(self.name, " for ", self.entity_state.name)
        return


    def is_inside(self, pos):
        if pos[0] < self.entity_state.dimensions[0]:
            return False
        if pos[0] > self.entity_state.dimensions[0] + self.entity_state.dimensions[2]:
            return False
        if pos[1] < self.entity_state.dimensions[1]:
            return False
        if pos[1] > self.entity_state.dimensions[3] + self.entity_state.dimensions[1]:
            return False
        return True