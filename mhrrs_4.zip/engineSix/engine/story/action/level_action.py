# I have created new type of interactive function for items that need to be displayed based on actions that occur off of events.
# # It allows the flexibility of creating levels.

class LoadLevels():
    def __init__(self):
        self.types = ["event"]
        self.entity_state = None
        self.children = []
        self.name = "load level action"
        self.verbose = False
        return

    def condition_to_act(self, data):
        if self.entity_state == None:
            return False
        if self.entity_state.active == False:
            return False
        if data == None:
            return False
        return True

    def act(self, data):
        if self.condition_to_act(data):
            print(str(data))
            self.load_lvl(data)



    def load_lvl(self,data):
       pass
    # maybe you could insert some specific functtion specific to the game into the children list here and act upon it here?