class Level():
    def __init__(self):
        self.actions = []
        self.name = "Level Entity"
        self.active = True
        self.verbose = False
        self.level_no = 1
        return


    def insert_action(self, a):
        a.entity_state = self
        self.actions.append(a)
        return