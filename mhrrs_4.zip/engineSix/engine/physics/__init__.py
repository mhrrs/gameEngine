

def make_particle():
    import physics.entity.particleEntity as part
    res = part.Particle()
    return res

def make_rectangle_collider(llc, urc):
    import physics.entity.rectangleCollider as rc
    res = rc.RectangleCollider(llc=llc, urc=urc)
    return res

def make_inside_rectangle_collision():
    import physics.action.rectangleColliderAction as rca
    return rca.InsideRectangleCollisionAction()

def make_outside_rectangle_collision():
    import physics.action.rectangleColliderAction as rca
    return rca.OutsideRectangleCollisionAction()

def make_gravity_force():
    import physics.entity.gravityForceEntity as F
    res = F.GravityForce()
    return res

def make_drag_force():
    import physics.entity.dragForceEntity as F
    res = F.DragForce()
    return res

def make_springy_force():
    import physics.entity.springForceEntity as F
    res = F.SpringyForce()
    return res

def make_gravity_action():
    import physics.action.gravityForceAction as F
    res = F.GravityForceAction()
    return res

def make_springy_action():
    import physics.action.springForceAction as F
    res = F.SpringForceAction()
    return res

def make_drag_action():
    import physics.action.dragForceAction as dF
    res = dF.DragForceAction()
    return res

def make_position_solve_action():
    import physics.action.positionSolve as solv
    return solv.PositionSolveAction()

def make_euler_solve_action():
    import physics.action.eulerSolve as solv
    return solv.EulerSolveAction()

def make_velocity_solve_action():
    import physics.action.velocitySolve as solv
    return solv.VelocitySolveAction()


def make_pick_position_action(index):
    import physics.action.Position as pos
    res = pos.PickPosition(index)
    return res

def make_put_position_action():
    import physics.action.Position as pos
    res = pos.PutPosition()
    return res

def make_put_pos_action():
    import physics.action.Put as pos
    res = pos.PutPositionAction()
    return res

def make_active():
    import physics.action.activate as activ
    result = activ.activate()
    return result

def make_deactive():
    import physics.action.deactivate as deactiv
    result = deactiv.activate()
    return result