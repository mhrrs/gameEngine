# activate and deactivate functions

class activate(object):
    def __init__(self):
        self.types = ["event"]
        self.entity_state = None
        self.verbose = True
        self.active = False
        self.name = "activate_button"
        return

    def condition_to_act(self, data):
        if self.active == False:
            return False
        if self.entity_state == False:
            return False
        return True

    def act(self, data):
        if self.condition_to_act(data):
            self.activator()
            if self.verbose:
                print(self.name, " for ", self.entity_state.name)
        return

    def activator(self):
        self.entity_state.active = True
        print("ITEM ACTIVATED")
        return