
# passes the center position from the entity to the child actions
class PickPosition(object):
    def __init__(self, index):
        self.types = ["position"]
        self.particle_index = index
        self.entity_state = None
        self.children = []
        self.name = "pick_position_action"
        self.verbose = False
        # self.active = True
        return

    def condition_to_act(self, data):
        if self.entity_state == False:
            return False
        if self.entity_state.active == False:
            return False
        if self.particle_index >= len(self.entity_state.position):
            return False
        if self.entity_state.active_particle[self.particle_index] == False:
            return False
        return True

    def act(self, data):
        if self.condition_to_act(data):
            new_data = list(self.entity_state.position[self.particle_index])
            for c in self.children:
                c.act(new_data) 
            if self.verbose == True:
                print(self.name, " for ", self.entity_state.name)


# puts the position passed to the action into the center location of the bounds of the entity
class PutPosition(object):
    def __init__(self):
        self.types = ["position"]
        self.entity_state = None
        self.children = []
        self.name = "put_position_action"
        self.verbose = False
        self.active = True
        return

    def condition_to_act(self, data):
        if self.entity_state == False:
            return False
        if self.entity_state.active == False:
            return False
        if len(data) != 2:
            return False
        return True

    def act(self, data):
        if self.condition_to_act(data):
            self.entity_state.position = list(data)
            
            for c in self.children:
                c.act(data)
            if self.verbose == True:
                print(self.name, " for ", self.entity_state.name)
            return