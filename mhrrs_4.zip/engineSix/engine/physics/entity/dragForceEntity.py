class DragForce(object):
    def __init__(self, name = "Drag_Force_Entity"):
        self.drag_constant = 5
        self.actions = []
        self.name = name
        self.verbose = False
        self.active = True
        return

    def insert_action(self, action):
        action.entity_state = self
        self.actions.append(action)
        return