class GravityForce(object):
    def __init__(self, name = "Gravity_Force_Entity"):
        self.gravity = [0.0,-1.0]
        self.actions = []
        self.name = name
        self.verbose = False
        self.active = True
        return

    def insert_action(self, action):
        action.entity_state = self
        self.actions.append(action)
        return