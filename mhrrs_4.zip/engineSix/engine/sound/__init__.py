
def make_box_hit_sound():
    import sound.action.buttonSound as bhs
    return bhs.buttonSoundAction()