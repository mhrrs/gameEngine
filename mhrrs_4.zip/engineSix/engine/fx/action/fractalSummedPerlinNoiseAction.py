

class FractalSummedPerlinNoise(object):
    def __init__(self):
        pass