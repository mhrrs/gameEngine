import pygame, sys
from pygame.locals import *
import os
import random

# adding folders/ MAKE SURE YOU ARE IN THE CORRECT LOCATION
# sys.path.append('C://Users//Michael Harris//Desktop//Masters CS//Clemson MSCS//2D_gameEngineConstruction//cannon_fodder//engineFive//engine')
from os.path import dirname, abspath
d = dirname(dirname(abspath(__file__)))
d += '\engine'
sys.path.append(d)
print(sys.path)

import actor as ac
import play as pl
import ui as ui
import utility as util
import sound as snd


#################### IN-GAME FUNCTIONS ##########################################

class generate_message_action(object):
    def __init__(self):
        self.types = ["display"]
        self.entity_state = None
        self.children = []
        self.time = None
        self.total = 0
        self.name = "gen_message"
        self.level = 1
        self.active = False

    def condition_to_act(self, data):
        if self.entity_state == False:
            return False
        if data == None:
            return False
        return True

    def act(self, data):
        if self.condition_to_act(data):
            self.generate_message(data)

    def generate_message(self, data):

        # organizing children names
        update_timer = self.children[0]
        restart_timer = self.children[1]

        if self.active == True:
            self.total = self.time
            self.level += 1
            restart_timer.start_timer(data)
            self.active = False

        # pass values of time entities to hud_action
        self.time = round(((1/1000) * update_timer.passed_time),2)
        


class generateBoxesEntity():
    def __init__(self):
        self.actions = []
        self.entity_state = None
        self.name = "box_generator"
        self.verbose = False
        self.active = True
        return

    def insert_action(self, a):
        a.entity_state = self
        self.actions.append(a)
        return
        

class generateBoxes():
    def __init__(self):
        self.entity_state = None
        self.types = ["event"]
        self.name = "generate_boxes_action"
        self.active = False
        self.children = []
        self.level = 1
        self.modify = 2
        self.box_size = 55
        self.box_count = 4
        self.boxes = []

    def condition_to_act(self, data):
        if self.entity_state == False:
            return False
        if self.entity_state.active == False:
            return False
        if data.type == MOUSEBUTTONDOWN:
            return False
        for i in self.boxes:
            if i.active == True:
                return False
        return True

    def act(self, data):
        if self.condition_to_act(data):
            print("LOADING NEW LEVEL")
            self.get_boxes(data)


    def get_boxes(self, data):

        # organizing children:
        display = self.children[0]
        game_content = self.children[1]
        gen_message = self.children[2]
        event_loop = self.children[3]


        # opportunity for garbage collection
        if len(self.boxes) > 0:
            print("DESTROYING OLD BOXES")
            for i in self.boxes:
                del i

            # display new time to screen 
            gen_message.active = True
            gen_message.generate_message(self.level)

            # update level counter
            self.level += 1

        # reinitialize the array
        self.boxes = []

        # increasing difficulty of newly generated boxes
        if self.box_size >= 11:
            self.box_size = self.box_size - 5
        else:
            self.box_count += 1

        # button creation
        for i in range(0,self.box_count):
            dimensions = (random.choice(range(50,1200)),random.choice(range(50,680)),self.box_size,self.box_size)
            color = (random.choice(range(0,255)),random.choice(range(0,255)),random.choice(range(0,255)))
            button = ui.make_basic_button(dimensions,color)
            button.insert_action(ui.make_button_draw())
            button.insert_action(ui.make_color_change())
            press_action = ui.make_button_pressed()
            deactivate_button = util.make_deactive()
            press_action.children.append(deactivate_button)
            button.insert_action(press_action)
            button.insert_action(deactivate_button)
            button.name = "box_"+str(i)+"_level_"+str(self.level)

            # inserting button into gameplay and box record
            self.boxes.append(button)
            display.insert_entity(button)
            game_content.append(button)
            
            for i in button.actions:
                event_loop.insert_action(i)
        
        



####################### INITIALIZE START SCREEN ##########################################

pygame.init()

# generate boxes
generate_entity = generateBoxesEntity()
box_generator = generateBoxes()
generate_entity.insert_action(box_generator)

# display window
viewer = pl.frameViewerEntity(title = "Clicker", name = "Clicker Window")
viewer.insert_action(pl.make_terminate_action())
display = pl.make_frameViewerAction()

# start screen
# Set the background color to white
viewer.window.fill((255, 255, 255))

# Display some text on the screen
font = pygame.font.Font(None, 36)
text = font.render('Click to begin', True, (0, 0, 0))
text_rect = text.get_rect()
text_rect.centerx = viewer.window.get_rect().centerx
text_rect.centery = viewer.window.get_rect().centery
viewer.window.blit(text, text_rect)

# Update the display
pygame.display.flip()


################################ GAME LOGIC #####################################################

def main():
    # init and add generate_message and draw_hud to HUD entity
    hud = util.make_hud_entity()
    hud_action = util.make_hud_action()
    hud.insert_action(hud_action)
    gen_message = generate_message_action()
    hud.insert_action(gen_message)

    # init timer entity
    timer_entity = util.make_timer_entity()
    update_timer_action = util.make_updateTimer_action()
    timer_start_action = util.make_startTimer_action()
    update_timer_action.children.append(timer_start_action)

    # adding actions to entity
    timer_entity.insert_action(update_timer_action)
    timer_entity.insert_action(timer_start_action)

    # change timer tick time
    timer_entity.tick_time = 60

    # add time info to gen_message
    gen_message.children.append(update_timer_action)
    gen_message.children.append(timer_start_action)

    # insert hud into frameviewer action
    display.insert_entity(hud)

    # inserting window into frameviewer entity
    viewer.insert_action(display)

    # adding entities to game_content
    game_content = [viewer]

    display.insert_entity(generate_entity)
    game_content.append(generate_entity)

    display.insert_entity(timer_entity)
    game_content.append(timer_entity)

    box_generator.children.append(display)
    box_generator.children.append(game_content)
    box_generator.children.append(gen_message)

    # run game loop
    game = pl.make_gameLoopAction(game_content)

    # TESTING:
    box_generator.children.append(game)

    game.loop()


################ OPEN START SCREEN AND WAIT FOR CLICK TO BEGIN GAME LOGIC ####################

# Run the game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # when screen is clicked, start gameplay
            main()

# Quit Pygame
pygame.quit()