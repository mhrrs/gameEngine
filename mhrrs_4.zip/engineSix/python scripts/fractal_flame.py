import pygame, sys
from pygame.locals import *
import os
import random

# adding folders/ MAKE SURE YOU ARE IN THE CORRECT LOCATION
# sys.path.append('C://Users//Michael Harris//Desktop//Masters CS//Clemson MSCS//2D_gameEngineConstruction//cannon_fodder//engineFive//engine')
from os.path import dirname, abspath
d = dirname(dirname(abspath(__file__)))
d += '\engine'
sys.path.append(d)

import actor as ac
import play as pl
import ui as ui
import utility as util
import sound as snd



################################ GAME LOGIC #####################################################

def main():
    pygame.init()

    # display window
    viewer = pl.frameViewerEntity(title = "Clicker", name = "Clicker Window")
    viewer.insert_action(pl.make_terminate_action())
    display = pl.make_frameViewerAction()

    # inserting window into frameviewer entity
    viewer.insert_action(display)

    # adding entities to game_content
    game_content = [viewer]

    # run game loop
    game = pl.make_gameLoopAction(game_content)

    game.loop()

main()