import pygame
from pygame.locals import *
import random
import sys
from os.path import dirname, abspath

# adding folders
# sys.path.append('C://Users//Michael Harris//Desktop//Masters CS//Clemson MSCS//2D_gameEngineConstruction//cannon_fodder//engineSix')
# sys.path.append("C:\\Users\\Michael Harris\\Desktop\Masters CS\\Clemson MSCS\\2D_gameEngineConstruction\\cannon_fodder\\engineFive\\engine")

d = dirname(dirname(abspath(__file__)))
d += '\engine'
sys.path.append(d)
print(sys.path)

import actor as ac
import play as pl
import ui as ui
import utility as util
import sound as snd
import physics as ph



#######################################
##
## random_color and random position
##

def random_color():
    rred = random.randrange(0,255)
    rgreen = random.randrange(0,255)
    rblue = random.randrange(0,255)
    return (rred,rgreen,rblue)


def random_pos():
    randx = random.choice(range(0,600))
    randy = random.choice(range(0,720))
    return (randx,randy)


##
## GET_CIRCLES METHOD
##

def get_circles(nx, ny, nb):
    circles = []
    radius = 10
    for i in range(0,nb):
        circle_bounds = random_pos()
        circle_color = random_color()

        circle = ac.make_basic_circle(circle_bounds[0],circle_bounds[1],radius)
        circle.color = circle_color
        circle.verbose = True
        circle.insert_action(ac.make_draw_circle())
        circles.append(circle)

    return circles
#######################################


#######################################
##
## PHYSICS
##

psolve = ph.make_position_solve_action()
inside_right_rect = ac.make_is_inside()
inside_left_rect = ac.make_is_inside()

#TESTING:
parts = ph.make_particle()
activate_particle = util.make_active()
deactivate_particle = util.make_deactive()
parts.insert_action(activate_particle)
parts.insert_action(deactivate_particle)

################## BUTTON (GRAD PART) #################################################
drag_button = ui.make_basic_button((0,0,1280,720), (255,0,0))
drag_button_action = ui.make_button_pressed()
drag_button.insert_action(drag_button_action)


def get_particles(init_data, nx, ny):
    particles = []

    particles.append(parts)

    for d in init_data:
        position = list(d.position)
        velocity = [(2.0*random.random()+15.20), (2.0*random.random()-4.75)]
        mass = 1.0
        parts.add_particle(position, velocity, mass)
    
    # force. In this case, simple gravity
    gravity = ph.make_gravity_force()
    gravity.gravity = [0.0,0.3]
    grav_action = ph.make_gravity_action()
    gravity.insert_action(grav_action)
    grav_action.children.append(inside_left_rect)
    grav_action.children.append(activate_particle)
    grav_action.children.append(inside_right_rect)

    # spring force
    spring = ph.make_springy_force()
    spring_action = ph.make_springy_action()
    spring.spring_constant = .03
    spring.insert_action(spring_action)
    spring_action.children.append(inside_right_rect)
    spring_action.children.append(activate_particle)

    # drag force
    drag = ph.make_drag_force()
    drag.drag_constant = .05
    drag_action = ph.make_drag_action()
    drag.insert_action(drag_action)
    drag_action.children.append(inside_left_rect)
    drag_action.children.append(activate_particle)
    drag_button_action.children.append(drag_action)

    parts.insert_action(psolve)

    vsolve = ph.make_velocity_solve_action()
    parts.insert_action(vsolve)
    vsolve.children.append(spring_action)
    vsolve.children.append(grav_action)
    vsolve.children.append(drag_action)

    esolve = ph.make_euler_solve_action()
    esolve.dt = 0.5
    parts.insert_action(esolve)
    esolve.children.append(psolve)
    esolve.children.append(vsolve)
    esolve.types.append("loop")

    # connect particle positions to circle positions
    for i in range(0, len(init_data)):
        pick = ph.make_pick_position_action(i)
        put = ph.make_put_position_action()
       
        parts.insert_action(pick)
        init_data[i].insert_action(put)
        pick.children.append(put)

        esolve.children.append(pick)

    # collisions with window frame
    window_frame_collider = ph.make_rectangle_collider([0,0], [nx,ny])
    collisions = ph.make_inside_rectangle_collision()
    window_frame_collider.insert_action(collisions)
    psolve.children.append(collisions)

    # collisions with a rectangle in the center of the frame
    top_collider = ph.make_rectangle_collider([nx/2+200, 0], [nx/2+275,250])
    outside_collisions = ph.make_outside_rectangle_collision()
    top_collider.insert_action(outside_collisions)
    psolve.children.append(outside_collisions)

    bottom_collider = ph.make_rectangle_collider([nx/2+200, ny/2+50], [nx/2+275,ny/2+400])
    outside_collisions = ph.make_outside_rectangle_collision()
    bottom_collider.insert_action(outside_collisions)
    psolve.children.append(outside_collisions)

    ground_collider_one = ph.make_rectangle_collider([nx/2+390, ny/2+170], [nx/2+590,ny/2+185])
    outside_collisions = ph.make_outside_rectangle_collision()
    ground_collider_one.insert_action(outside_collisions)
    psolve.children.append(outside_collisions)

    ground_collider_two = ph.make_rectangle_collider([nx/2+415, ny/2+250], [nx/2+615,ny/2+265])
    outside_collisions = ph.make_outside_rectangle_collision()
    ground_collider_two.insert_action(outside_collisions)
    psolve.children.append(outside_collisions)

    return particles


#######################################
##
## get_boxes
##
def get_boxes(nx,ny):
    boxes = []
    top_rect = ac.make_basic_rectangle(nx/2+200,0,75,250,(255,255,255))
    top_rect.insert_action(ac.make_draw_rectangle())
    top_rect.name = "top_rect"

    bottom_rect = ac.make_basic_rectangle(nx/2+200,ny/2+50,75,400,(255,255,255))
    bottom_rect.insert_action(ac.make_draw_rectangle())
    bottom_rect.name = "bottom_rect"

    ground_rect_one = ac.make_basic_rectangle(nx/2+390,ny/2+170,200,15,(255,255,255))
    ground_rect_one.insert_action(ac.make_draw_rectangle())
    ground_rect_one.name = "ground_rect_1"

    ground_rect_two = ac.make_basic_rectangle(nx/2+415,ny/2+250,200,15,(255,255,255))
    ground_rect_two.insert_action(ac.make_draw_rectangle())
    ground_rect_two.name = "ground_rect_2"

    boxes.append(bottom_rect)
    boxes.append(top_rect)
    boxes.append(ground_rect_one)
    boxes.append(ground_rect_two)


    return boxes



#######################################

def main():
    pygame.init()

    # display window
    viewer = pl.frameViewerEntity(title = "Cannon Fodder", name = "Cannon Fodder Window")
    viewer.insert_action(pl.make_terminate_action())
    display = pl.make_frameViewerAction()

    NX = 1280
    NY = 720

    #################### particles ######################
    # create 100 spheres
    circs = get_circles(NX,NY,100)
    particles = get_particles(circs, NX, NY)
    boxes = get_boxes(NX, NY)


    #################### TIMER ##########################
    # make rect and rect timer
    rectangle_timer = util.make_timer_entity()
    rect_timer_action = util.make_startTimer_action()

    # INSERT ACITVATE INTO UPDATE TIMER, when it finally passes the time threshold, it'll activate the rect
    rect_timer_update = util.make_updateTimer_action()
    rectangle_timer.insert_action(rect_timer_action)
    rectangle_timer.insert_action(rect_timer_update)

    # inserting activate_pillar into update_timer as a child and into rect_block as an action
    activate_pillar = ph.make_active()
    activate_pillar_collider = ph.make_active()
    rect_timer_update.children.append(activate_pillar) #the rect_block.insert_action for this is in the rect section

    rect_timer_alarm = util.make_alarmTimer_action()
    rect_timer_alarm.children.append(rect_timer_action)
    rect_timer_alarm.children.append(activate_pillar)
    rect_timer_alarm.children.append(activate_pillar_collider)
    rect_timer_update.children.append(rect_timer_alarm)
    rectangle_timer.insert_action(rect_timer_alarm)

    #################### RECTANGLES AND COLLIDERS FOR POP UP PILLAR #######################
    rect_block = ac.make_basic_rectangle(NX/2+200, NY/2-200,75,400,(255,255,255))
    rect_block.insert_action(ac.make_draw_rectangle())
    rect_block.insert_action(activate_pillar)
    rect_block.active = False

    mid_collider = ph.make_rectangle_collider([NX/2+200, NY/2-200], [NX/2+275,NY/2+400])
    mid_collider.active = False
    outside_collisions = ph.make_outside_rectangle_collision()
    mid_collider.insert_action(outside_collisions)
    mid_collider.insert_action(activate_pillar_collider)
    psolve.children.append(outside_collisions)



    #################### INVISIBLE RIGHT SIDE #############################################

    # TESTING --> develop is_inside method to have particle constantly track position. If position is inside dimensions of right side, then terminate forces
    # I need to find a way to deactivate the forces for particles on this side.

    right_side_rect = ac.make_basic_rectangle(NX/2+275,0,600,800,(0,0,255))
    # right_side_rect.insert_action(ac.make_draw_rectangle())
    inside_right_rect.children.append(deactivate_particle)
    right_side_rect.insert_action(inside_right_rect)

    ################### INVISIBLE LEFT SIDE ###############################################

    left_side_rect = ac.make_basic_rectangle(0,0,850,720,(0,0,200))
    # left_side_rect.insert_action(ac.make_draw_rectangle())
    left_side_rect.insert_action(inside_left_rect)
    inside_left_rect.children.append(deactivate_particle)

    #################################### VIEWER ###########################################
    # inserting window into frameviewer entity
    viewer.insert_action(display)

    # adding entities to game_content
    game_content = [viewer]

    # adding circs and particles
    game_content += circs + particles + boxes

    game_content.append(rectangle_timer)
    game_content.append(rect_block)
    display.insert_entity(rect_block)

    game_content.append(right_side_rect)
    display.insert_entity(right_side_rect)

    game_content.append(left_side_rect)
    display.insert_entity(left_side_rect)

    game_content.append(drag_button)
    display.insert_entity(drag_button)

    # pass draw action to the gameLooper
    for b in circs+boxes:
        display.insert_entity(b)
        print("circ pos: ",b.position)
    
    for i in boxes:
        print("rect created: ", i.name)


    # run game loop
    game = pl.make_gameLoopAction(game_content)
    game.loop()


main()