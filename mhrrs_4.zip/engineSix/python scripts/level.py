import pygame, sys
from pygame.locals import *
import os
import random
from os.path import dirname, abspath

# adding folders/ MAKE SURE YOU ARE IN THE CORRECT LOCATION
# sys.path.append('C://Users//Michael Harris//Desktop//Masters CS//Clemson MSCS//2D_gameEngineConstruction//game engine Jam//engineFive//engine')
d = dirname(dirname(abspath(__file__)))
d += '\engine'
sys.path.append(d)
print(sys.path)

import actor as ac
import play as pl
import ui as ui
import utility as util
import sound as snd


class Level():
    def __init__(self):
        self.actions = []
        self.name = "Level Entity"
        self.active = True
        self.verbose = False
        self.level_no = 1
        self.counter = 1  #level counter
        return


    def insert_action(self, a):
        a.entity_state = self
        self.actions.append(a)
        return



class LoadLevels():
    def __init__(self):
        self.types = ["display"]
        self.entity_state = None
        self.children = []
        self.name = "load_level_action"
        self.verbose = False
        self.objects = []
        return

    def condition_to_act(self, data):
        if self.entity_state == None:
            return False
        if self.entity_state.active == False:
            return False
        if data == None:
            return False
        return True

    def act(self, data): #data here is the screen object
        if self.condition_to_act(data):
            self.load_lvl(data)

    def load_lvl(self,data):
        print("here") # it is getting here
        # take buttons from children and turn each active = True based on number of levels
        for i in range(0, self.entity_state.counter):
            print(self.children[i].name, " | ", self.children[i].active)   
            # should I instead call my childrens actions? this way if the button is clicked, it is connected here? 
            # should "level" have increment or press_button?
            self.children[i].active = True



############################## GENERATE SQUARES #######################################

increment_level = util.make_increment_action()

def get_buttons(): #only getting called once
    buttons = []
    NX = 10
    NY = 10
    NW = 20
    NH = 40

    for i in range(0,23):

        if NX >= 720:
            NX = 10
            NY = 80

        NX += 50
        card = ui.make_basic_button((NX, NY, NW, NH),(255,255,255))
        press_button = ui.make_button_pressed()
        press_button.children.append(increment_level)

        # insert actions
        card.insert_action(ui.make_button_draw())
        card.insert_action(press_button)

        # modify card
        card.name = "card_"+str(i)
        card.active = False

        # add card to list that gets added to load_level children
        buttons.append(card)

    return buttons



# display window
viewer = pl.frameViewerEntity(title = "Game Engine Jam", name = "Game Engine Jam Window")
viewer.insert_action(pl.make_terminate_action())
display = pl.make_frameViewerAction()

#generate display and functionality of buttons
buttons = get_buttons()

# create load_levels and insert buttons into children
level = Level()
load_levels = LoadLevels()
level.insert_action(load_levels)
level.insert_action(increment_level)
for i in buttons:
    load_levels.children.append(i)

# inserting window into frameviewer entity
viewer.insert_action(display)

# adding entities to game_content
game_content = [viewer]

# add level to content and viewer
game_content.append(level)
display.insert_entity(level)

# adding buttons to game_content and display
for i in buttons:
    display.insert_entity(i)
    game_content.append(i)

# run game loop
game = pl.make_gameLoopAction(game_content)
game.loop()